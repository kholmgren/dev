package io.kettil.fn.liiklus;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class SourceEvent {
    private String id;
    private long seq;
    private int value;

    @JsonIgnore
    private LocalDateTime nextUpdate;
}