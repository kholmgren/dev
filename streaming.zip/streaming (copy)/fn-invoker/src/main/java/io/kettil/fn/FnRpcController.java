package io.kettil.fn;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.function.context.FunctionCatalog;
import org.springframework.cloud.function.context.FunctionProperties;
import org.springframework.cloud.function.context.catalog.SimpleFunctionRegistry;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class FnRpcController {
    // curl -XPOST -H 'Content-Type:application/json' http://localhost:8080 -d '{"id":"x:123","value":321}'
    // curl -XPOST -H 'Content-Type:application/json' http://localhost:8080 -d '{"id":"item:17","timestamp":"2020-11-22 09:57:48","value":34}'

    // curl -XPOST -H 'Content-Type:application/json' http://localhost:8080 -d '{"id":"item:3","seq":66,"value":0}'

    private final FunctionCatalog catalog;
    private final FunctionProperties functionProperties;
    private ObjectMapper mapper;
    private FnProperties fnProperties;

    public FnRpcController(ObjectMapper mapper, FnProperties fnProperties, FunctionCatalog functionCatalog, FunctionProperties functionProperties) {
        this.mapper = mapper;
        this.fnProperties = fnProperties;
        this.catalog = functionCatalog;
        this.functionProperties = functionProperties;
    }

    @SneakyThrows
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Object invoke(@RequestBody Object requestBody) {
        SimpleFunctionRegistry.FunctionInvocationWrapper wrapper = catalog.lookup(functionProperties.getDefinition());
        Object value = mapper.convertValue(requestBody, wrapper.getRawInputType());
        Object ret = wrapper.apply(value);

        log.info("{}:{} --> {}:{}",
                wrapper.getRawInputType().getCanonicalName(), requestBody,
                wrapper.getRawOutputType().getCanonicalName(), ret);

        return ret;
    }
}
