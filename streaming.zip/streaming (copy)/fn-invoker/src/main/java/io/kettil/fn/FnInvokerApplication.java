package io.kettil.fn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FnInvokerApplication {
    public static void main(String[] args) {
        // FN_LOCATION=../functions/derp/target/derp-1.0-SNAPSHOT.jar;FN_NAME=io.kettil.fn.Derp
        // FN_LOCATION=../functions/derp2/target/derp2-1.0-SNAPSHOT.jar;FN_NAME=io.kettil.fn.Derp2
        // FN_LOCATION=../functions/simplest/target/simplestjar-1.0.0.RELEASE.jar;FN_NAME=function.example.UpperCaseFunction
        // FN_LOCATION=../functions/taggy/target/taggy-1.0-SNAPSHOT.jar;FN_NAME=io.kettil.fn.Taggy

        SpringApplication.run(FnInvokerApplication.class);
    }
}
