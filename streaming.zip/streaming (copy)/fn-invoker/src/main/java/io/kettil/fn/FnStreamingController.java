package io.kettil.fn;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bsideup.liiklus.protocol.*;
import com.google.protobuf.ByteString;
import io.grpc.ManagedChannel;
import io.grpc.netty.NettyChannelBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.function.context.FunctionCatalog;
import org.springframework.cloud.function.context.FunctionProperties;
import org.springframework.cloud.function.context.catalog.SimpleFunctionRegistry;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.UUID;

@Service
@Slf4j
public class FnStreamingController implements CommandLineRunner {
    private final FunctionCatalog catalog;
    private final FunctionProperties functionProperties;

    @Value("${liiklus.host}")
    private String liiklusHost;
    @Value("${liiklus.port}")
    private int liiklusPort;
    private ObjectMapper mapper;
    private FnProperties fnProperties;

    public FnStreamingController(ObjectMapper mapper, FnProperties fnProperties, FunctionCatalog functionCatalog, FunctionProperties functionProperties) {
        this.mapper = mapper;
        this.fnProperties = fnProperties;
        this.catalog = functionCatalog;
        this.functionProperties = functionProperties;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("fnProperties=" + fnProperties);

        ManagedChannel channel = NettyChannelBuilder.forTarget(liiklusHost + ":" + liiklusPort)
                .directExecutor()
                .usePlaintext()
                .build();

        log.info("opened channel");

        ReactorLiiklusServiceGrpc.ReactorLiiklusServiceStub stub = ReactorLiiklusServiceGrpc.newReactorStub(channel);

        log.info("created service stub");

        SubscribeRequest inSubscribeRequest = SubscribeRequest.newBuilder()
                .setTopic(fnProperties.getInTopic())
                .setGroup(fnProperties.getInGroup())
                .setAutoOffsetReset(SubscribeRequest.AutoOffsetReset.LATEST)
                .build();

        Flux<ReceiveReply.LiiklusEventRecord> eventRecordFlux = stub
                .subscribe(inSubscribeRequest)
                .filter(it -> it.getReplyCase() == SubscribeReply.ReplyCase.ASSIGNMENT)
                .map(SubscribeReply::getAssignment)
                .flatMap(assignment -> stub
                        .receive(ReceiveRequest.newBuilder().setAssignment(assignment).setFormat(ReceiveRequest.ContentFormat.LIIKLUS_EVENT).build())
                        .map(ReceiveReply::getLiiklusEventRecord)
                        .doOnNext(record -> {
                            try {
                                SimpleFunctionRegistry.FunctionInvocationWrapper wrapper = catalog.lookup(functionProperties.getDefinition());

                                Object value = mapper.readValue(record.getEvent().getData().toByteArray(), wrapper.getRawInputType());

                                Object ret = wrapper.apply(value);

                                LiiklusEvent.Builder builder = LiiklusEvent.newBuilder()
                                        .setId(UUID.randomUUID().toString())
                                        .setType("io.kettil.fn.event")
                                        .setSource("/example")
                                        .setDataContentType("application/json");

                                if (ret != null)
                                    builder.setData(ByteString.copyFrom(mapper.writeValueAsBytes(ret)));

                                LiiklusEvent liiklusEvent = builder.build();

                                PublishRequest publishRequest = PublishRequest.newBuilder()
                                        .setTopic(fnProperties.getOutTopic())
                                        .setKey(ByteString.copyFromUtf8(UUID.randomUUID().toString()))
                                        .setLiiklusEvent(liiklusEvent)
                                        .build();

                                stub
                                        .publish(publishRequest)
                                        .subscribe();

                            } catch (IOException e) {
                                e.printStackTrace();
                            } finally {
                                log.debug("ACKing partition {} offset {}", assignment.getPartition(), record.getOffset());
                                stub.ack(
                                        AckRequest.newBuilder()
                                                .setTopic(inSubscribeRequest.getTopic())
                                                .setGroup(inSubscribeRequest.getGroup())
                                                .setGroupVersion(inSubscribeRequest.getGroupVersion())
                                                .setPartition(assignment.getPartition())
                                                .setOffset(record.getOffset())
                                                .build());
                            }
                        })
                );

        log.info("running");

        try {
            eventRecordFlux
                    .doOnError(ee -> {
                        ee.printStackTrace();
                    })
                    .blockLast();
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }
}
