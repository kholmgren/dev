package io.kettil.fn.deploy.model;

public enum ManifestRuntimes {
    Java8
}
