### UnRiff and manifest

Demo a way to deploy functions using a minimal manifest and execute them on streams without using *project riff*.

#### Flow
* topic:source-events --> fn:derp --> topic:derped-events
* topic:derped-events --> fn:taggy --> topic:taggied-events

#### Start the liiklus gateway

```bash
docker-compose up
```

##### View Kafka configuration and status

http://localhost:9021


#### Generate some traffic

```bash
java -jar liiklus-source/target/liiklus-source.jar \
--topic source-events
```

#### Verify events are being generated on the topic

```bash
java -jar liiklus-sink/target/liiklus-sink.jar \
--topic source-events
```

#### View the Derp function's manifest

```bash
cat functions/derp/manifest.yaml 
```

#### Deploy derp in a runtime-built container

```bash
java -jar fn-deploy/target/fn-deploy.jar \
--invoker-jar fn-invoker/target/fn-invoker-1.0.jar \
--function-repo functions/derp
```

#### Verify that derp is publishing events on its topic

```bash
java -jar liiklus-sink/target/liiklus-sink.jar \
--topic derped-events
```


#### View the Taggy function's manifest

```bash
cat functions/taggy/manifest.yaml 
```

#### Deploy taggy in a runtime-built container

```bash
java -jar fn-deploy/target/fn-deploy.jar \
--invoker-jar fn-invoker/target/fn-invoker-1.0.jar \
--function-repo functions/taggy
```

#### View events that have been processed by derp and then taggy

```bash
java -jar liiklus-sink/target/liiklus-sink.jar \
--topic taggied-events
```
