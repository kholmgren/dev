package io.kettil.fn;

import lombok.Data;

@Data
public class DerpedEvent {
    private String id;
    private long seq;
    private String value;
}