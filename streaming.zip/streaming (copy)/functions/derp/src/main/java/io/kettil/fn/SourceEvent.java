package io.kettil.fn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceEvent {
    private String id;
    private long seq;
    private int value;
}