package io.kettil.fn;

import java.util.function.Function;

public class Derp implements Function<SourceEvent, DerpedEvent> {
    @Override
    public DerpedEvent apply(SourceEvent value) {
        if (value == null)
            return null;

        DerpedEvent ret = new DerpedEvent();
        ret.setId(value.getId());
        ret.setSeq(value.getSeq());
        ret.setValue(SpellOutNumber.of(Double.valueOf(Integer.toString(value.getValue())).longValue()));

        return ret;
    }
}
