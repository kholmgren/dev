package io.kettil.fn;

import lombok.Data;

import java.util.Set;
import java.util.TreeSet;

@Data
public class TaggiedEvent {
    private String id;
    private long seq;
    private String value;
    private final Set<String> tags = new TreeSet<>(String::compareToIgnoreCase);
}