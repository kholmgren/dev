package io.kettil.fn;

import java.util.Random;
import java.util.function.Function;

public class Taggy implements Function<DerpedEvent, TaggiedEvent> {
    private final Random random = new Random();
    private final String[] colors = new String[]{"blue", "green", "yellow", "red"};
    private final String[] levels = new String[]{"low", "medium", "high"};

    @Override
    public TaggiedEvent apply(DerpedEvent value) {
        if (value == null)
            return null;

        TaggiedEvent ret = new TaggiedEvent();
        ret.setId(value.getId());
        ret.setSeq(value.getSeq());

        if (value.getValue() != null)
            ret.setValue(value.getValue().toUpperCase());

        ret.getTags().add("color:" + colors[random.nextInt(colors.length)]);
        ret.getTags().add("level:" + levels[random.nextInt(levels.length)]);
        ret.getTags().add("tagged-by:taggy");

        return ret;
    }
}
